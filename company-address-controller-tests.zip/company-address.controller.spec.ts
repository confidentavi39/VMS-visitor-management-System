
import { Test, TestingModule } from '@nestjs/testing';
import { CompanyAddressController } from './company-address.controller';
import { CompanyAddressService } from './company-address.service';
import { CreateCompanyAddressDto } from './dto/create-company-address.dto';
import { UpdateCompanyAddressDto } from './dto/update-company-address.dto';

describe('CompanyAddressController', () => {
  let controller: CompanyAddressController;
  let service: CompanyAddressService;

  const mockService = {
    create: jest.fn(dto => ({ id: '1', ...dto })),
    findAllByCompany: jest.fn(companyId => [`Address 1 for ${companyId}`]),
    findOne: jest.fn(id => ({ id, name: 'Head Office' })),
    update: jest.fn((id, dto) => ({ id, ...dto })),
    remove: jest.fn(id => ({ deleted: true })),
  };

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CompanyAddressController],
      providers: [
        { provide: CompanyAddressService, useValue: mockService }
      ],
    }).compile();

    controller = module.get<CompanyAddressController>(CompanyAddressController);
    service = module.get<CompanyAddressService>(CompanyAddressService);
  });

  it('should create an address', async () => {
    const dto: CreateCompanyAddressDto = { address: '123 Main St', city: 'TestCity', state: 'TestState', pincode: '123456' };
    const result = await controller.create('company-1', dto);
    expect(result).toEqual({ id: '1', ...dto });
    expect(service.create).toHaveBeenCalledWith('company-1', dto);
  });

  it('should return all addresses for a company', async () => {
    const result = await controller.findAll('company-1');
    expect(result).toEqual(['Address 1 for company-1']);
    expect(service.findAllByCompany).toHaveBeenCalledWith('company-1');
  });

  it('should return a specific address', async () => {
    const result = await controller.findOne('1');
    expect(result).toEqual({ id: '1', name: 'Head Office' });
    expect(service.findOne).toHaveBeenCalledWith('1');
  });

  it('should update an address', async () => {
    const dto: UpdateCompanyAddressDto = { address: 'Updated Address' };
    const result = await controller.update('1', dto);
    expect(result).toEqual({ id: '1', ...dto });
    expect(service.update).toHaveBeenCalledWith('1', dto);
  });

  it('should delete an address', async () => {
    const result = await controller.remove('1');
    expect(result).toEqual({ deleted: true });
    expect(service.remove).toHaveBeenCalledWith('1');
  });
});
