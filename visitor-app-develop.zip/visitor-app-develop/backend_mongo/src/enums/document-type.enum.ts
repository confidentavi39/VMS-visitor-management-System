export enum DocumentTypeEnum {
  PAN = 1,
  AADHAR = 2,
  DRIVING_LICENSE = 3,
}
