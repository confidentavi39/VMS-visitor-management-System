// src/settings/schemas/settings.schema.ts

import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { Schema as MongooseSchema } from 'mongoose';

@Schema({ timestamps: true })
export class Settings extends Document {
  @Prop({ type: MongooseSchema.Types.ObjectId, ref: 'VisitorRegistration', required: true, unique: true })
  visitorId: string; 

  @Prop({ default: true })
  dob_flag: boolean;

  @Prop({ default: true })
  profile_path_flag: boolean;

  @Prop({ default: true })
  alternate_contact_flag: boolean;

  @Prop({ default: true })
  email_flag: boolean;
}

export const SettingsSchema = SchemaFactory.createForClass(Settings);

SettingsSchema.index({ visitorId: 1 });
