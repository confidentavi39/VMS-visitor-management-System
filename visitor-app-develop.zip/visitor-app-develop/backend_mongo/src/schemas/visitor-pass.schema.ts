import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { Document } from 'mongoose';

@Schema({ timestamps: true })
export class VisitorPass extends Document {
  // @Prop({ required: true, ref: 'VisitorRegistration' })
  // visitor_id: string;

  // @Prop({ required: true })
  // client_id: string;

  @Prop({ required: true, type: mongoose.Schema.Types.ObjectId, ref: 'VisitorRegistration' })
  visitor_id: mongoose.Types.ObjectId;

  @Prop({ required: true, type: mongoose.Schema.Types.ObjectId, ref: 'Clients' })
  client_id: mongoose.Types.ObjectId;

  @Prop({required: true})
  whom_to_visit: string

  @Prop({ required: true })
  date: Date;

  @Prop({required: true})
  planned_in_time: Date;

  @Prop({required: true})
  planned_out_time: Date;

  @Prop()
  in_time: Date;

  @Prop()
  out_time: Date;

  @Prop()
  created_by: string;

  @Prop()
  updated_by: string;
}

export const VisitorPassSchema = SchemaFactory.createForClass(VisitorPass);