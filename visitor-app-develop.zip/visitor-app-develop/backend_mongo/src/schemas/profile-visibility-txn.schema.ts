import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { Document } from 'mongoose';

@Schema({ timestamps: true })
export class ProfileVisibilityTxn extends Document {
  @Prop({ required: true, type: mongoose.Schema.Types.ObjectId, ref: 'VisitorRegistration' })
  visitor_id: mongoose.Types.ObjectId;

  @Prop({ required: true, type: mongoose.Schema.Types.ObjectId, ref: 'Clients' })
  client_id: mongoose.Types.ObjectId;

  // @Prop({ required: true, ref: 'VisitorRegistration' })
  // visitor_id: string;

  // @Prop({ required: true })
  // client_id: string;

  @Prop({ default: 0, enum: [0, 1, 2] })
  status: number; // 0-Pending, 1-Approved, 2-Rejected

  @Prop()
  reason_for_rejection: string;
}

export const ProfileVisibilityTxnSchema = SchemaFactory.createForClass(ProfileVisibilityTxn);