import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';

@Schema({ _id: true })
export class DocumentFile {
  @Prop({ required: true })
  documentPath: string;

  @Prop({ required: true })
  documentTypeId: number;

  @Prop({ default: true })
  isVisible: boolean;
}

export const DocumentFileSchema = SchemaFactory.createForClass(DocumentFile);

@Schema()
export class VisitorDocument extends Document {
  @Prop({ required: true })
  visitorId: string;

  @Prop({ type: [DocumentFileSchema], default: [] })
  idProof: Types.DocumentArray<DocumentFile>;
}

export const VisitorDocumentSchema = SchemaFactory.createForClass(VisitorDocument);
