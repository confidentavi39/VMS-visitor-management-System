import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

@Schema({ timestamps: true })
export class VisitorRegistration extends Document {
  @Prop({ required: true })
  profile_photo_url: string;

  @Prop({ required: true })
  firstname: string;

  @Prop({ required: true })
  lastname: string;

  @Prop({
    required: true,
    unique: true,
  })
  mobile_no: string;

  // @Prop({
  //   required: true,
  //   unique: true,
  //   validate: {
  //     validator: (v: string) => /^[0-9]{10}$/.test(v),
  //     message: (props) =>
  //       `${props.value} is not a valid 10 digit phone number!`,
  //   },
  // })
  // mobile_no: string;

  @Prop({ required: true, unique: true })
  email_id: string;

  @Prop({
  required: true,
  validate: {
    validator: function(v: Date) {
      return v < new Date(); // Ensure date is in past
    },
    message: 'Date of birth must be in the past'
  }
})
dob: Date;

  @Prop({ required: true, enum: ['male', 'female', 'other'] })
  gender: string;

  @Prop({ required: true })
  address: string;

  @Prop({ default: 'active' })
  status: string;

  @Prop({ default: 'NO' })
  is_blacklisted: string;

  @Prop()
  alternate_contact: string;

  @Prop({ default: false })
  otp_verified: boolean;

  @Prop()
  created_by: string;

  @Prop()
  updated_by: string;
}

export const VisitorRegistrationSchema =
  SchemaFactory.createForClass(VisitorRegistration);
