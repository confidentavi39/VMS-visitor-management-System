import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { Otp } from 'src/schemas/otp.schema';


@Injectable()
export class OtpService {
  constructor(
    @InjectModel(Otp.name) private otpModel: Model<Otp>,
    private configService: ConfigService,
  ) {}

  

  async generateOtp(mobile_no: string): Promise<string> {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes expiry

    await this.otpModel.findOneAndUpdate(
      { mobile_no },
      { otp, expiresAt },
      { upsert: true, new: true },
    );

    // In production, send OTP via SMS/email here
    console.log(`OTP for ${mobile_no}: ${otp}`);

    return otp;
  }

  async verifyOtp(mobile_no: string, otp: string): Promise<boolean> {
    const otpRecord = await this.otpModel.findOneAndDelete({
      mobile_no,
      otp,
      expiresAt: { $gt: new Date() },
    });

    return !!otpRecord;
  }

  async deleteOtp(mobile_no: string): Promise<void> {
    await this.otpModel.deleteOne({ mobile_no });
  }
}