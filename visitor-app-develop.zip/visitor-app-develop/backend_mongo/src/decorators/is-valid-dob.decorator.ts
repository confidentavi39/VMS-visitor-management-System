import { registerDecorator, ValidationOptions, ValidationArguments } from 'class-validator';

export function IsValidDob(validationOptions?: ValidationOptions) {
  return function (object: Object, propertyName: string) {
    registerDecorator({
      name: 'isValidDob',
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      validator: {
        validate(value: any, args: ValidationArguments) {
          if (typeof value !== 'string') return false;
          const [day, month, year] = value.split('-');
          const date = new Date(`${year}-${month}-${day}`);
          
          // Check if date is valid and not in future
          return date instanceof Date && 
                 !isNaN(date.getTime()) && 
                 date < new Date();
        },
        defaultMessage(args: ValidationArguments) {
          return 'Invalid date of birth (must be dd-mm-yyyy and valid date)';
        }
      }
    });
  };
}