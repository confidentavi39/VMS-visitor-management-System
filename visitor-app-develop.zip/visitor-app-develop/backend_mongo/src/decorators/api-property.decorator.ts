import { applyDecorators } from '@nestjs/common';
import { ApiProperty, ApiPropertyOptions } from '@nestjs/swagger';

export function ApiPropertyWithExamples(
  examples: any[],
  options?: ApiPropertyOptions
) {
  return applyDecorators(
    ApiProperty({
      ...options,
      examples: examples.reduce((acc, example, index) => {
        acc[`Example ${index + 1}`] = { value: example };
        return acc;
      }, {}),
    })
  );
}