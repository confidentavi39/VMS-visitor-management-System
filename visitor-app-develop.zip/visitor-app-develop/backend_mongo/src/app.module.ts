import { ServeStaticModule } from '@nestjs/serve-static';
import * as path from 'path';
import { Module, OnModuleInit } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { connection } from 'mongoose';
import { AuthModule } from './auth/auth.module';

import { OtpModule } from './otp/otp.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ProfileModule } from './auth/profile/profile.module';
import { SettingsModule } from './auth/settings/settings.module';
import { DocumentsModule } from './documents/documents.module';
import { VisitorPassModule } from './auth/visitor_pass/visitor_pass.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        uri: configService.get<string>('MONGODB_URI'),
      }),
      inject: [ConfigService],
    }),

    ServeStaticModule.forRoot({
      rootPath: path.join(__dirname, '..', 'uploads'),
      serveRoot: '/uploads',
    }),
    AuthModule,
    OtpModule,
    ProfileModule,
AuthModule,
OtpModule,
    SettingsModule,

    DocumentsModule,

    VisitorPassModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule implements OnModuleInit {
  constructor(private readonly configService: ConfigService) { }

  onModuleInit() {
    this.setupMongoConnection();
  }

  private setupMongoConnection() {
    const dbName = this.configService.get<string>('MONGODB_URI')?.split('/').pop()?.split('?')[0];

    connection.on('connected', () => {
      console.log(`Successfully connected to MongoDB database: ${dbName}`);
    });

    connection.on('error', (err) => {
      console.error('MongoDB connection error:', err);
      process.exit(1);
    });

    connection.on('disconnected', () => {
      console.log('MongoDB connection disconnected');
    });

    connection.on('reconnected', () => {
      console.log('MongoDB connection reestablished');
    });

    connection.on('close', () => {
      console.log('MongoDB connection closed');
    });
  }
}