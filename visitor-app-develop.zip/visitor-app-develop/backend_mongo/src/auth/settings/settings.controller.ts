// src/settings/settings.controller.ts

import { Controller, Get, Post, Put, Body, Param } from '@nestjs/common';
import { SettingsService } from './settings.service';
import { CreateSettingsDto } from './dto/create-setting.dto';
import { UpdateSettingsDto } from './dto/update-setting.dto';
import { Settings } from '../../schemas/settings.schema';
import { ApiTags, ApiOperation, ApiResponse, ApiParam } from '@nestjs/swagger';

@ApiTags('Settings')
@Controller('settings')
export class SettingsController {
  constructor(private readonly settingsService: SettingsService) {}

  @Post()
  @ApiOperation({ summary: 'Create settings for a new visitor' })
  @ApiResponse({ status: 201, description: 'Settings created successfully' })
  async createSettings(@Body() body: CreateSettingsDto): Promise<Settings> {
    return this.settingsService.createSettings(body);
  }

  @Put()
  @ApiOperation({ summary: 'Update or create settings (upsert) for a visitor' })
  @ApiResponse({ status: 200, description: 'Settings updated successfully' })
  async updateSettings(@Body() body: UpdateSettingsDto): Promise<Settings> {
    return this.settingsService.upsertSettings(body);
  }

  @Get(':visitorId')
  @ApiOperation({ summary: 'Get settings for a visitor' })
  @ApiParam({ name: 'visitorId', type: String })
  @ApiResponse({ status: 200, description: 'Settings retrieved successfully' })
  async getSettings(@Param('visitorId') visitorId: string): Promise<Settings> {
    return this.settingsService.getSettings(visitorId);
  }
}
