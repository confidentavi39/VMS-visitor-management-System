
import { ApiProperty } from '@nestjs/swagger';

export class CreateSettingsDto {
  @ApiProperty()
  visitorId: string;

  @ApiProperty({ default: true })
  dob_flag: boolean;

  @ApiProperty({ default: true })
  profile_path_flag: boolean;

  @ApiProperty({ default: true })
  alternate_contact_flag: boolean;

  @ApiProperty({ default: true })
  email_flag: boolean;
}
