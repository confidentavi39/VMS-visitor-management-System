
import { Injectable, ConflictException, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Settings } from '../../schemas/settings.schema';
import { VisitorRegistration } from '../../schemas/visitor-registration.schema';
import { CreateSettingsDto } from './dto/create-setting.dto';
import { UpdateSettingsDto } from './dto/update-setting.dto';

@Injectable()
export class SettingsService {
  constructor(
    @InjectModel(Settings.name) private settingsModel: Model<Settings>,
    @InjectModel(VisitorRegistration.name) private visitorModel: Model<VisitorRegistration>,
  ) { }

  async createSettings(data: CreateSettingsDto): Promise<Settings> {

    const visitor = await this.visitorModel.findOne({ _id: data.visitorId });
    if (!visitor) {
      throw new ConflictException(`Visitor not exists`);
    }


    const exists = await this.settingsModel.findOne({ visitorId: data.visitorId });
    if (exists) {
      throw new ConflictException(`Settings already exist for visitorId: ${data.visitorId}`);
    }

    const created = new this.settingsModel({
      visitorId: data.visitorId,
      dob_flag: true,
      profile_path_flag: true,
      alternate_contact_flag: true,
      email_flag: true,
    });
    return created.save();
  }

  async upsertSettings(data: UpdateSettingsDto): Promise<Settings> {
    return this.settingsModel.findOneAndUpdate(
      { visitorId: data.visitorId },
      { $set: data },
      { new: true, upsert: true }
    );
  }

  async getSettings(visitorId: string): Promise<Settings> {
    const settings = await this.settingsModel
      .findOne({ visitorId })
      .populate('visitorId');
    console.log(settings)
    if (!settings) {
      throw new NotFoundException(`Settings not found for visitorId: ${visitorId}`);
    }
    return settings;
  }
}
