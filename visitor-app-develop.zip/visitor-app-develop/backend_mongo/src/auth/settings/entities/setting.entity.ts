export class Setting {}
