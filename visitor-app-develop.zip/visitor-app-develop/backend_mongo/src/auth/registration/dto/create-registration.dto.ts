export class CreateRegistrationDto {}
