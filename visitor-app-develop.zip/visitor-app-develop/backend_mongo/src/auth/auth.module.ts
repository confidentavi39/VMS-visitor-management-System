import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { PassportModule } from '@nestjs/passport';
import { MongooseModule } from '@nestjs/mongoose';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { VisitorRegistration, VisitorRegistrationSchema } from '../schemas/visitor-registration.schema';
import { SettingsModule } from './settings/settings.module';
import { VisitorPassModule } from './visitor_pass/visitor_pass.module';
import { RegistrationModule } from './registration/registration.module';
import { JwtStrategy } from './strategies/jwt.strategy';
import { OtpModule } from '../otp/otp.module';
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: VisitorRegistration.name, schema: VisitorRegistrationSchema },
    ]),
    PassportModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        secret: configService.get<string>('JWT_SECRET'),
        signOptions: { expiresIn: configService.get<string>('JWT_EXPIRES_IN') },
      }),
      inject: [ConfigService],
    }),
    SettingsModule,
    OtpModule,
    VisitorPassModule,
    RegistrationModule,
    OtpModule, // <-- Add OtpModule here
  ],
  controllers: [AuthController],
  providers: [AuthService, JwtStrategy],
  exports: [AuthService],
})
export class AuthModule {}
