import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
} from '@nestjs/common';
import { ProfileService } from './profile.service';
import { CreateProfileDto } from './dto/create-profile.dto';
import { UpdateProfileDto } from './dto/update-profile.dto';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiBody,
  ApiQuery,
} from '@nestjs/swagger';

// @UseGuards(AuthGuard('jwt'))
@ApiTags('profiles')
@Controller('profile')
export class ProfileController {
  constructor(private readonly service: ProfileService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new profile' })
  @ApiResponse({ status: 201, description: 'Profile created successfully' })
  @ApiBody({ type: CreateProfileDto })
  async create(@Body() dto: CreateProfileDto) {
    return this.service.create(dto);
  }

  @Get()
@ApiOperation({ summary: 'Retrieve all profiles with pagination' })
@ApiResponse({ status: 200, description: 'List of all profiles' })
@ApiQuery({ name: 'page', required: false, type: Number, example: 1, description: 'Page number' })
@ApiQuery({ name: 'limit', required: false, type: Number, example: 10, description: 'Number of items per page' })
async findAll(
  @Query('page') page = 1,
  @Query('limit') limit = 10,
) {
  return this.service.findAll(+page, +limit);
}

  @Get(':id')
  @ApiOperation({ summary: 'Get profile by ID' })
  @ApiParam({ name: 'id', description: 'MongoDB ObjectId of the profile' })
  @ApiResponse({ status: 200, description: 'Profile found' })
  @ApiResponse({ status: 404, description: 'Profile not found' })
  async findOne(@Param('id') id: string) {
    return this.service.findOne(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update a profile by ID' })
  @ApiParam({ name: 'id', description: 'MongoDB ObjectId of the profile' })
  @ApiResponse({ status: 200, description: 'Profile updated successfully' })
  @ApiBody({ type: UpdateProfileDto })
  async update(@Param('id') id: string, @Body() dto: UpdateProfileDto) {
    return this.service.update(id, dto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a profile by ID' })
  @ApiParam({ name: 'id', description: 'MongoDB ObjectId of the profile' })
  @ApiResponse({ status: 200, description: 'Profile deleted successfully' })
  async remove(@Param('id') id: string) {
    return this.service.remove(id);
  }
}
