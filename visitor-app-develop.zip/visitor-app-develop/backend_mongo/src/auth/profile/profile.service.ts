import {
  Injectable,
  NotFoundException,
  BadRequestException,
  InternalServerErrorException,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { ProfileVisibilityTxn } from 'src/schemas/profile-visibility-txn.schema';
import { CreateProfileDto } from './dto/create-profile.dto';
import { UpdateProfileDto } from './dto/update-profile.dto';

@Injectable()
export class ProfileService {
  constructor(
    @InjectModel(ProfileVisibilityTxn.name)
    private readonly model: Model<ProfileVisibilityTxn>,
  ) {}

  async create(dto: CreateProfileDto): Promise<ProfileVisibilityTxn> {
  try {
    if (dto.status === 2 && !dto.reason_for_rejection) {
      throw new BadRequestException('Reason for rejection is required if status is 2');
    }

    const created = new this.model(dto);
    return await created.save();
  } catch (error) {
    console.error('Profile creation error:', error); 
    throw new BadRequestException('Failed to create transaction', { cause: error });
  }
}

  async findAll(page: number, limit: number): Promise<ProfileVisibilityTxn[]> {
       const skip = (page - 1) * limit;
      try {
        return await this.model.find().sort({ createdAt: -1 }).skip(skip)
      .limit(limit).exec();
      } catch (error) {
        console.error('Error fetching visitor passes:', error); 
        throw new InternalServerErrorException('Failed to fetch transactions', { cause: error });
      }
    }

  async findOne(visitorId: string): Promise<ProfileVisibilityTxn[]> {
    try {
      const txn = await this.model.find({ visitor_id: visitorId }).sort({ createdAt: -1 }).exec();
      if (!txn || txn.length === 0) {
        throw new NotFoundException(`Transaction with ID ${visitorId} not found`);
      }
      return txn;
    } catch (error) {
      if (error instanceof NotFoundException) throw error;
      throw new BadRequestException('Invalid ID format or fetch error', { cause: error });
    }
  }

 async update(id: string, dto: UpdateProfileDto): Promise<ProfileVisibilityTxn> {
  try {
    if (dto.status === 2 && !dto.reason_for_rejection) {
      throw new BadRequestException('Reason for rejection is required if status is 2');
    }

    const updated = await this.model.findByIdAndUpdate(id, dto, { new: true }).exec();
    
    if (!updated) {
      throw new NotFoundException(`Transaction with ID ${id} not found`);
    }

    return updated;
  } catch (error) {
    console.error('Error during transaction update:', error);

    if (error instanceof BadRequestException) {
      throw error; 
    }
    
    throw new BadRequestException('Failed to update transaction', { cause: error });
  }
}

  async remove(id: string): Promise<ProfileVisibilityTxn> {
    try {
      const deleted = await this.model.findByIdAndDelete(id).exec();
      if (!deleted) {
        throw new NotFoundException(`Transaction with ID ${id} not found`);
      }
      return deleted;
    } catch (error) {
      throw new BadRequestException('Failed to delete transaction', { cause: error });
    }
  }
}
