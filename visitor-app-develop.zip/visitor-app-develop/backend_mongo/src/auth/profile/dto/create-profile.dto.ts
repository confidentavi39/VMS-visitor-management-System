import { IsNotEmpty, IsOptional, IsIn, IsMongoId } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateProfileDto {
  @ApiProperty({
    description: 'MongoDB ObjectId of the visitor',
    example: '665fa3d1f6d3c1f9f1a8c9a4',
    type: String,
  })
  @IsNotEmpty()
  @IsMongoId()
  visitor_id: string;

  @ApiProperty({
    description: 'MongoDB ObjectId of the client',
    example: '665fa3e2f6d3c1f9f1a8c9b7',
    type: String,
  })
  @IsNotEmpty()
  @IsMongoId()
  client_id: string;

  @ApiPropertyOptional({
    description: 'Profile status: 0 = Pending, 1 = Approved, 2 = Rejected',
    enum: [0, 1, 2],
    example: 0,
  })
  @IsOptional()
  @IsIn([0, 1, 2])
  status?: number;

  @ApiPropertyOptional({
    description: 'Reason for rejection (only applicable if status = 2)',
    example: 'Incomplete documents',
  })
  @IsOptional()
  reason_for_rejection?: string;
}
