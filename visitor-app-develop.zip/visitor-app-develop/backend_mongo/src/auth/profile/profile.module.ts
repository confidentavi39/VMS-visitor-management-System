import { Module } from '@nestjs/common';
import { ProfileService } from './profile.service';
import { ProfileController } from './profile.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { ProfileVisibilityTxn, ProfileVisibilityTxnSchema } from 'src/schemas/profile-visibility-txn.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: ProfileVisibilityTxn.name, schema: ProfileVisibilityTxnSchema }
    ]),
  ],
  controllers: [ProfileController],
  providers: [ProfileService],
})

export class ProfileModule {}