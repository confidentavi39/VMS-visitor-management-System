import {
  Injectable,
  NotFoundException,
  BadRequestException,
  InternalServerErrorException,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { VisitorPass } from 'src/schemas/visitor-pass.schema';
import { CreateVisitorPassDto } from './dto/create-visitor_pass.dto';
import { UpdateVisitorPassDto } from './dto/update-visitor_pass.dto';

@Injectable()
export class VisitorPassService {
  constructor(
    @InjectModel(VisitorPass.name)
    private readonly model: Model<VisitorPass>,
  ) {}

 async create(dto: CreateVisitorPassDto): Promise<VisitorPass> {
  try {
    if (dto.planned_in_time && dto.planned_out_time && new Date(dto.planned_out_time) <= new Date(dto.planned_in_time)) {
      throw new BadRequestException('Out time must be greater than In time');
    }

    const created = new this.model(dto);
    return await created.save();
  } catch (error) {
    console.error('Error creating visitor pass:', error);
    if (error.code === 11000) {
      throw new BadRequestException('Visitor pass already exists');
    }

    if (error instanceof BadRequestException) throw error;
    throw new InternalServerErrorException('Failed to create visitor pass', { cause: error });
  }
}



  async findAll(page: number, limit: number): Promise<VisitorPass[]> {
     const skip = (page - 1) * limit;
    try {
      return await this.model.find().sort({ createdAt: -1 }).skip(skip)
    .limit(limit).exec();
    } catch (error) {
      console.error('Error fetching visitor passes:', error); 
      throw new InternalServerErrorException('Failed to fetch visitor passes', { cause: error });
    }
  }

  async findOne(visitor_id: string): Promise<VisitorPass[]> {
    try {
      const pass = await this.model.find({ visitor_id }).exec();
      if (!pass) {
        throw new NotFoundException(`Visitor pass with ID ${visitor_id} not found`);
      }
      return pass;
    } catch (error) {
      console.error('Error fetching visitor pass:', error); 
      if (error instanceof NotFoundException) throw error;
      throw new InternalServerErrorException('Failed to fetch visitor pass', { cause: error });
    }
  }

  async update(id: string, dto: UpdateVisitorPassDto): Promise<VisitorPass> {
  try {

     if (dto.planned_in_time && dto.planned_out_time && new Date(dto.planned_out_time) <= new Date(dto.planned_in_time)) {
      throw new BadRequestException('Out time must be greater than In time');
    }

    if (dto.out_time && dto.in_time && new Date(dto.out_time) <= new Date(dto.in_time)) {
      throw new BadRequestException('Out time must be greater than In time');
    }

    const updated = await this.model.findByIdAndUpdate(id, dto, { new: true }).exec();
    if (!updated) {
      throw new NotFoundException(`Visitor pass with ID ${id} not found`);
    }
    return updated;
  } catch (error) {
    if (error instanceof BadRequestException) throw error;
    console.error('Error updating visitor pass:', error);
    if (error instanceof NotFoundException) throw error;
    throw new InternalServerErrorException('Failed to update visitor pass', { cause: error });
  }
}


  async remove(id: string): Promise<VisitorPass> {
    try {
      const deleted = await this.model.findByIdAndUpdate( id ).exec();
      if (!deleted) {
        throw new NotFoundException(`Visitor pass with ID ${id} not found`);
      }
      return deleted;
    } catch (error) {
      console.error('Error deleting visitor pass:', error); 
      if (error instanceof NotFoundException) throw error;
      throw new InternalServerErrorException('Failed to delete visitor pass', { cause: error });
    }
  }
}
