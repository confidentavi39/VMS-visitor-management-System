import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { VisitorPass, VisitorPassSchema } from 'src/schemas/visitor-pass.schema';
import { VisitorPassController } from './visitor_pass.controller';
import { VisitorPassService } from './visitor_pass.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: VisitorPass.name, schema: VisitorPassSchema },
    ]),
  ],
  controllers: [VisitorPassController],
  providers: [VisitorPassService],
})
export class VisitorPassModule {}
