import { Test, TestingModule } from '@nestjs/testing';
import { VisitorPassController } from './visitor_pass.controller';
import { VisitorPassService } from './visitor_pass.service';

describe('VisitorPassController', () => {
  let controller: VisitorPassController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [VisitorPassController],
      providers: [VisitorPassService],
    }).compile();

    controller = module.get<VisitorPassController>(VisitorPassController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
