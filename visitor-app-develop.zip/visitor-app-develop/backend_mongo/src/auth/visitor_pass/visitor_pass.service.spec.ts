import { Test, TestingModule } from '@nestjs/testing';
import { VisitorPassService } from './visitor_pass.service';

describe('VisitorPassService', () => {
  let service: VisitorPassService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [VisitorPassService],
    }).compile();

    service = module.get<VisitorPassService>(VisitorPassService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
