import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
} from '@nestjs/common';
import { VisitorPassService } from './visitor_pass.service';
import { CreateVisitorPassDto } from './dto/create-visitor_pass.dto';
import { UpdateVisitorPassDto } from './dto/update-visitor_pass.dto';

import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiBody,
  ApiQuery,
} from '@nestjs/swagger';

@ApiTags('visitor-passes') // Shows as a group in Swagger UI
@Controller('visitor-pass')
export class VisitorPassController {
  constructor(private readonly service: VisitorPassService) {}

  @Post()
  @ApiOperation({ summary: 'Create a new visitor pass' })
  @ApiResponse({ status: 201, description: 'Visitor pass created successfully' })
  @ApiBody({ type: CreateVisitorPassDto })
  create(@Body() dto: CreateVisitorPassDto) {
    return this.service.create(dto);
  }

  @Get()
  @ApiOperation({ summary: 'Get all visitor passes' })
  @ApiResponse({ status: 200, description: 'List of visitor passes' })
  @ApiQuery({ name: 'page', required: false, type: Number, example: 1 })
@ApiQuery({ name: 'limit', required: false, type: Number, example: 10 })
  findAll(
    @Query('page') page = 1,
    @Query('limit') limit = 10
  ) {
    return this.service.findAll(+page, +limit);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a visitor pass by ID' })
  @ApiParam({ name: 'id', description: 'MongoDB ObjectId of the visitor pass' })
  @ApiResponse({ status: 200, description: 'Visitor pass found' })
  @ApiResponse({ status: 404, description: 'Visitor pass not found' })
  findOne(@Param('id') id: string) {
    return this.service.findOne(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Update a visitor pass by ID' })
  @ApiParam({ name: 'id', description: 'MongoDB ObjectId of the visitor pass' })
  @ApiBody({ type: UpdateVisitorPassDto })
  @ApiResponse({ status: 200, description: 'Visitor pass updated successfully' })
  update(@Param('id') id: string, @Body() dto: UpdateVisitorPassDto) {
    return this.service.update(id, dto);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'Delete a visitor pass by ID' })
  @ApiParam({ name: 'id', description: 'MongoDB ObjectId of the visitor pass' })
  @ApiResponse({ status: 200, description: 'Visitor pass deleted successfully' })
  remove(@Param('id') id: string) {
    return this.service.remove(id);
  }
}
