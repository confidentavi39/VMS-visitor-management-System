import { IsNotEmpty, IsOptional, IsDateString, IsMongoId } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateVisitorPassDto {
  @ApiProperty({
    description: 'MongoDB ObjectId of the visitor',
    example: '665fa3d1f6d3c1f9f1a8c9a4',
    type: String,
  })
  @IsNotEmpty()
  @IsMongoId()
  visitor_id: string;

  @ApiProperty({
    description: 'MongoDB ObjectId of the client',
    example: '665fa3e2f6d3c1f9f1a8c9b7',
    type: String,
  })
  @IsNotEmpty()
  @IsMongoId()
  client_id: string;

  @ApiProperty({
    description: 'Name or ID of the person the client intends to visit',
    example: 'john_doe_123',
  })
  @IsNotEmpty()
  whom_to_visit: string;

  @ApiProperty({
    description: 'Date of the visit',
    example: '2025-05-20',
    type: String,
    format: 'date',
  })
  @IsNotEmpty()
  @IsDateString()
  date: Date;

  @ApiProperty({
    description: 'Planned check-in time',
    example: '2025-05-20T09:00:00.000Z',
  })
  @IsNotEmpty()
  @IsDateString()
  planned_in_time: Date;

  @ApiProperty({
    description: 'Planned check-out time',
    example: '2025-05-20T17:00:00.000Z',
  })
  @IsNotEmpty()
  @IsDateString()
  planned_out_time: Date;

  @ApiProperty({
    description: 'Actual check-in time',
    example: '2025-05-20T09:15:00.000Z',
  })
  @IsDateString()
  in_time: Date;

  @ApiPropertyOptional({
    description: 'Actual check-out time',
    example: '2025-05-20T16:45:00.000Z',
  })
  @IsOptional()
  @IsDateString()
  out_time?: Date;

  @ApiPropertyOptional({
    description: 'User who created the record',
    example: 'admin_user_1',
  })
  @IsOptional()
  created_by?: string;

  @ApiPropertyOptional({
    description: 'User who last updated the record',
    example: 'admin_user_2',
  })
  @IsOptional()
  updated_by?: string;
}