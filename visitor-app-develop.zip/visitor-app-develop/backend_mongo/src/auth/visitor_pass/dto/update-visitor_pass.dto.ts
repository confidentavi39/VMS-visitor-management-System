import { PartialType } from '@nestjs/mapped-types';
import { CreateVisitorPassDto } from './create-visitor_pass.dto';

export class UpdateVisitorPassDto extends PartialType(CreateVisitorPassDto) {}
