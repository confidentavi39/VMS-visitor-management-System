import { IsMobilePhone, IsNotEmpty, Matches } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class SendOtpDto {
  @ApiProperty({
    example: '9876543210',
    description: '10 digit mobile number without country code',
    required: true,
  })
  @IsMobilePhone('en-IN') // Or your locale
  @IsNotEmpty({ message: 'Mobile number is required' })
  @Matches(/^[0-9]{10}$/, {
    message: 'Mobile number must be exactly 10 digits',
  })
  mobile_no: string;
}
