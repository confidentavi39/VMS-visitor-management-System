import { ApiProperty } from '@nestjs/swagger';

export class LoginResponseDto {
  @ApiProperty({
    example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
    description: 'JWT access token'
  })
  access_token: string;

  @ApiProperty({
    example: '507f1f77bcf86cd799439011',
    description: 'User ID'
  })
  user_id: string;

  @ApiProperty({
    example: '1234567890',
    description: 'Mobile number'
  })
  mobile_no: string;
}