import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, Matches } from 'class-validator';

import { Transform } from 'class-transformer';
import { IsEmail, IsMobilePhone, IsDateString } from 'class-validator';
import { IsValidDob } from 'src/decorators/is-valid-dob.decorator';
export class RegisterDto {
  @ApiProperty({ type: 'string', format: 'binary' })
  profile_photo: Express.Multer.File;

  @ApiProperty({ example: 'John'})
  firstname: string;

  @ApiProperty({ example: 'Doe'})
  lastname: string;

  @ApiProperty()
  @IsMobilePhone()
  mobile_no: string;

  @ApiProperty({ example: 'john@example.com'})
  @IsEmail()
  email_id: string;

  @ApiProperty({
    example: '15-01-1990',
    description: 'Date of birth in dd-mm-yyyy format'
  })
  @IsNotEmpty()
  @IsValidDob()
  @Matches(/^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[012])-(19|20)\d\d$/, {
    message: 'Date must be in dd-mm-yyyy format (e.g. 15-01-1990)'
  })
  @Transform(({ value }) => {
    const [day, month, year] = value.split('-');
    return new Date(`${year}-${month}-${day}`); // Convert to Date object
  })
  dob: Date;

  @ApiProperty({ example: 'male', enum: ['male', 'female', 'other']})
  gender: string;

  @ApiProperty({ example: '123 Main St, City, Country'})
  address: string;

  @ApiProperty({ example: '123456'})
  otp: string;
}
