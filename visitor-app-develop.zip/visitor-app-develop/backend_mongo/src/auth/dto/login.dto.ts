export class LoginDto {
  readonly mobile_no: string;
}

export class VerifyLoginDto {
  readonly mobile_no: string;
  readonly otp: string;
}