import { IsMobilePhone, IsNotEmpty, Matches } from "class-validator";

export class VerifyOtpDto {
  @IsMobilePhone('en-IN')
  @IsNotEmpty()
  mobile_no: string;

  @Matches(/^[0-9]{6}$/)
  @IsNotEmpty()
  otp: string;
}