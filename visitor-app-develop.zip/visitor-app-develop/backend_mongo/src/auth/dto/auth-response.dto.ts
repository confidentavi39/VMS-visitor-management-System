import { ApiProperty } from '@nestjs/swagger';



export class AuthResponseDto {
  @ApiProperty({ example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...' })
  access_token: string;

  @ApiProperty({
    example: {
      id: '507f1f77bcf86cd799439011',
      mobile_no: '1234567890',
      name: 'John Doe'
    }
  })
  user: {
    id: string;
    mobile_no: string;
    name: string;
  };
}