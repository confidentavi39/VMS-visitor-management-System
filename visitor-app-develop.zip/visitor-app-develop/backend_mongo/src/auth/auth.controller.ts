import {
  Controller,
  Post,
  Body,
  UploadedFile,
  UseInterceptors,
} from '@nestjs/common';
import { AuthService } from './auth.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { VerifyOtpDto } from './dto/verify-otp.dto';
// import { SendOtpDto } from 'src/dto/send-otp.dto';
import {
  ApiTags,
  ApiOperation,
  ApiBody,
  ApiResponse,
  ApiConsumes,
} from '@nestjs/swagger';
import { AuthResponseDto } from './dto/auth-response.dto';
import { LoginResponseDto } from './dto/login-response.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname } from 'path';
import { SendOtpDto } from './dto/send-otp.dto';
import { response } from 'express';
@ApiTags('Authentication')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('send-otp')
  @ApiOperation({ summary: 'Send OTP to mobile number' })
  @ApiBody({ type: SendOtpDto })
  @ApiResponse({ status: 200, description: 'OTP sent successfully' })
  @ApiResponse({ status: 400, description: 'Invalid request' })
  async sendOtp(@Body() sendOtpDto: SendOtpDto) {
    return this.authService.sendOtp(sendOtpDto.mobile_no);
  }

  @Post('register')
  @UseInterceptors(
    FileInterceptor('profile_photo', {
      storage: diskStorage({
        destination: './uploads/profiles',
        filename: (req, file, cb) => {
          const randomName = Array(32)
            .fill(null)
            .map(() => Math.round(Math.random() * 16).toString(16))
            .join('');
          return cb(null, `${randomName}${extname(file.originalname)}`);
        },
      }),
    }),
  )
  @ApiOperation({ summary: 'Register new visitor with profile photo' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({ type: RegisterDto })
  async register(
    @UploadedFile() profilePhoto: Express.Multer.File,
    @Body() registerDto: Omit<RegisterDto, 'profile_photo'>,
  ) {
    return this.authService.registerWithOtp({
      ...registerDto,
      profile_photo: profilePhoto, // Ensure file is passed correctly
    });
  }
  // @ApiResponse({
  //   status: 201,
  //   description: 'User registered successfully',
  //   type: AuthResponseDto,
  // })
  // @ApiResponse({ status: 400, description: 'Invalid OTP or missing fields' })
  // async register(@Body() registerDto: RegisterDto) {
  //   return this.authService.registerWithOtp(registerDto);
  // }

  @Post('login/initiate') // New endpoint
  @ApiOperation({ summary: 'Initiate login by verifying user' })
  @ApiBody({ type: SendOtpDto })
  @ApiResponse({ status: 200, description: 'OTP sent if user exists' })
  @ApiResponse({ status: 404, description: 'User not registered' })
  async initiateLogin(@Body() { mobile_no }: SendOtpDto) {
    return this.authService.initiateLogin(mobile_no);
  }

  // // Keep existing verify endpoint
  // @Post('login/verify')
  // async verifyLogin(@Body() verifyOtpDto: VerifyOtpDto) {
  //   return this.authService.verifyLogin(verifyOtpDto);
  // }

  @Post('login/verify')
  @ApiOperation({ summary: 'Verify OTP for login' })
  @ApiBody({ type: VerifyOtpDto })
  @ApiResponse({
    status: 200,
    description: 'Login successful',
    type: LoginResponseDto,
  })
  @ApiResponse({ status: 401, description: 'Invalid OTP' })
  async verifyLogin(@Body() verifyOtpDto: VerifyOtpDto) {
    return this.authService.verifyLogin(verifyOtpDto);
  }
}
