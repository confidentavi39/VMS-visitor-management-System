import {
  Injectable,
  ConflictException,
  UnauthorizedException,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { Model } from 'mongoose';
import { InjectModel } from '@nestjs/mongoose';
import { VisitorRegistration } from '../schemas/visitor-registration.schema';
import { RegisterDto } from './dto/register.dto';
import { VerifyOtpDto } from './dto/verify-otp.dto';
import { OtpService } from '../otp/otp.service';
import { LoginDto } from './dto/login.dto';

@Injectable()
export class AuthService {
  constructor(
    @InjectModel(VisitorRegistration.name)
    private visitorModel: Model<VisitorRegistration>,
    private jwtService: JwtService,
    private configService: ConfigService,
    private otpService: OtpService,
  ) {}

  async sendOtp(mobile_no: string) {
    await this.otpService.generateOtp(mobile_no);
    return { message: 'OTP sent successfully' };
  }

  async registerWithOtp(registerDto: RegisterDto & { profile_photo: Express.Multer.File }) {
  // Destructure with proper typing
  const dob = registerDto.dob; 
  const { profile_photo, mobile_no, email_id, otp, ...userData } = registerDto;

  // 1. Verify OTP first
  if (!(await this.otpService.verifyOtp(mobile_no, otp))) {
    throw new UnauthorizedException('Invalid OTP');
  }

  // 2. Check for existing user
  const existingUser = await this.visitorModel.findOne({
    $or: [{ mobile_no }, { email_id }]
  });
  if (existingUser) {
    throw new ConflictException('User already exists');
  }

  // 3. Process file upload
  if (!profile_photo || !profile_photo.filename) {
    throw new BadRequestException('Profile photo is required');
  }

  // 4. Create user record
  const newVisitor = await this.visitorModel.create({
    ...userData,
    mobile_no,
    email_id,
    profile_photo_url: `/profile-photos/${profile_photo.filename}`, // Use filename
    otp_verified: true
  });

  // 5. Generate JWT
  const payload = { sub: newVisitor._id, mobile: newVisitor.mobile_no };
  
  return {
    access_token: this.jwtService.sign(payload),
    user: {
      id: newVisitor._id,
      name: `${newVisitor.firstname} ${newVisitor.lastname}`,
      email: newVisitor.email_id,
      profile_photo: newVisitor.profile_photo_url
    }
  };
}

  async verifyOtp(verifyOtpDto: VerifyOtpDto) {
    const { mobile_no, otp } = verifyOtpDto;

    if (!(await this.otpService.verifyOtp(mobile_no, otp))) {
      throw new UnauthorizedException('Invalid OTP');
    }

    return { message: 'OTP verified successfully' };
  }


  async initiateLogin(mobile_no: string) {
  // 1. Check user exists
  const user = await this.visitorModel.findOne({ mobile_no });
  if (!user) {
    throw new NotFoundException('User not registered');
  }
  
  // 2. Generate and send OTP
  const otp = await this.otpService.generateOtp(mobile_no);
  return { message: 'OTP sent to registered mobile' };
}

// Update verifyLogin (add user check)
async verifyLogin(verifyOtpDto: VerifyOtpDto) {
  // 1. Verify OTP
  const isValid = await this.otpService.verifyOtp(
    verifyOtpDto.mobile_no, 
    verifyOtpDto.otp
  );
  if (!isValid) throw new UnauthorizedException('Invalid OTP');

  // 2. Verify user exists again (defense in depth)
  const user = await this.visitorModel.findOne({ 
    mobile_no: verifyOtpDto.mobile_no 
  });
  if (!user) throw new NotFoundException('User not found');

  const payload = { sub: user._id, mobile: user.mobile_no };
  return {
    access_token: this.jwtService.sign(payload),
    user: {
      id: user._id,
      name: `${user.firstname} ${user.lastname}`,
      mobile_no: user.mobile_no
    }
  };
}

  async register(registerDto: RegisterDto) {
    // Check if user already exists
    const existingUser = await this.visitorModel.findOne({
      mobile_no: registerDto.mobile_no,
    });

    if (existingUser) {
      throw new Error('User already exists');
    }

    // Create user (not verified yet)
    const createdVisitor = new this.visitorModel(registerDto);
    await createdVisitor.save();

    // Generate and send OTP
    await this.otpService.generateOtp(registerDto.mobile_no);

    return { message: 'OTP sent to your mobile number' };
  }

  async verifyRegistration(verifyOtpDto: VerifyOtpDto) {
    const isOtpValid = await this.otpService.verifyOtp(
      verifyOtpDto.mobile_no,
      verifyOtpDto.otp,
    );

    if (!isOtpValid) {
      throw new Error('Invalid OTP');
    }

    // Mark user as verified
    const visitor = await this.visitorModel.findOneAndUpdate(
      { mobile_no: verifyOtpDto.mobile_no },
      { otp_verified: true },
      { new: true },
    );

    if (!visitor) {
      throw new Error('User not found');
    }

    // Generate JWT token
    const payload = {
      sub: visitor._id,
      mobile: visitor.mobile_no,
    };

    return {
      access_token: this.jwtService.sign(payload),
    };
  }

  async login(loginDto: { mobile_no: string }): Promise<{ message: string }> {
    const visitor = await this.visitorModel.findOne({
      mobile_no: loginDto.mobile_no,
    });

    if (!visitor) {
      throw new NotFoundException('User not found');
    }

    await this.otpService.generateOtp(loginDto.mobile_no);
    return { message: 'OTP sent to your mobile number' };
  }

  // async verifyLogin(verifyOtpDto: {
  //   mobile_no: string;
  //   otp: string;
  // }): Promise<{ access_token: string }> {
  //   // Verify OTP
  //   const isOtpValid = await this.otpService.verifyOtp(
  //     verifyOtpDto.mobile_no,
  //     verifyOtpDto.otp,
  //   );
  //   if (!isOtpValid) {
  //     throw new UnauthorizedException('Invalid OTP');
  //   }

  //   // Find user
  //   const visitor = await this.visitorModel.findOne({
  //     mobile_no: verifyOtpDto.mobile_no,
  //   });

  //   if (!visitor) {
  //     throw new NotFoundException('User not found');
  //   }

  //   // Generate JWT
  //   const payload = {
  //     sub: visitor._id,
  //     mobile: visitor.mobile_no,
  //   };

  //   return {
  //     access_token: this.jwtService.sign(payload),
  //   };
  // }
}
