export class Document {}
