import { IsBoolean, IsEnum, IsOptional } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export enum DocumentType {
  Pancard = 1,
  Adharcard = 2,
  DrivingLicense = 3,
}

export class DocumentFileDto {
  @ApiProperty({ enum: DocumentType, example: 1 })
  @IsEnum(DocumentType)
  documentTypeId: DocumentType;

  @ApiProperty({ example: true, required: false })
  @IsOptional()
  @IsBoolean()
  isVisible?: boolean;
}
