import { DocumentFileDto } from './document-file.dto';

export class VisitorDocumentDto {
  readonly visitorId: string;
  readonly idProof: DocumentFileDto[];
}
