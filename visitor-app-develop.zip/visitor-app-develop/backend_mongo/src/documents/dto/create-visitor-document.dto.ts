import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsArray, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { DocumentFileDto } from './document-file.dto';

export class CreateVisitorDocumentDto {
  @ApiProperty()
  @IsNotEmpty()
  visitorId: string;

  @ApiProperty({ type: [DocumentFileDto] })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => DocumentFileDto)
  metadata: DocumentFileDto[];
}
