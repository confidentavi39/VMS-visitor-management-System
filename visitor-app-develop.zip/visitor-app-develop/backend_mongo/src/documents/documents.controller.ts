import {
  Controller,
  Post,
  Param,
  UploadedFiles,
  UploadedFile,
  UseInterceptors,
  HttpCode,
  HttpStatus,
  Delete,
  Put,
  Body,
  BadRequestException,
} from '@nestjs/common';
import {
  FileInterceptor,
  FilesInterceptor,
} from '@nestjs/platform-express';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiConsumes,
  ApiBody,
} from '@nestjs/swagger';
import { DocumentsService } from './documents.service';
import { DocumentFileDto } from './dto/document-file.dto';

@ApiTags('Documents')
@Controller('documents')
export class DocumentsController {
  constructor(private readonly documentsService: DocumentsService) {}

  /**
   * Upload new documents for a visitor
   */
  @Post('upload/:visitorId')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Upload new documents for a visitor' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        files: {
          type: 'array',
          items: {
            type: 'string',
            format: 'binary',
          },
        },
        documentFileDto: {
          type: 'string', // JSON string in body
          description: 'JSON stringified array of metadata',
          example: JSON.stringify([
            { documentTypeId: 1, isVisible: true },
            { documentTypeId: 2, isVisible: false },
          ]),
        },
      },
    },
  })
  @ApiResponse({
    status: HttpStatus.CREATED,
    description: 'Documents uploaded successfully.',
  })
  @ApiResponse({
    status: HttpStatus.BAD_REQUEST,
    description: 'Invalid input or file format.',
  })
  @UseInterceptors(FilesInterceptor('files'))
  async uploadDocuments(
    @Param('visitorId') visitorId: string,
    @UploadedFiles() files: Array<Express.Multer.File>,
    @Body() body: any,
  ) {
    if (!files || files.length === 0) {
      throw new BadRequestException('No files uploaded');
    }

    let documentFileDto: DocumentFileDto[];

    try {
      documentFileDto = JSON.parse(body.documentFileDto);
    } catch {
      throw new BadRequestException('Invalid metadata format. Must be JSON string.');
    }

    if (files.length !== documentFileDto.length) {
      throw new BadRequestException(
        'Each file must have a corresponding metadata entry',
      );
    }

    return this.documentsService.uploadNewDocument(visitorId, files, documentFileDto);
  }

  /**
   * Update a document (metadata and/or file)
   */
  @Put('update/:visitorId/:documentId')
  @HttpCode(HttpStatus.OK)
  @UseInterceptors(FileInterceptor('file'))
  @ApiOperation({ summary: 'Update document file or metadata' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: {
          type: 'string',
          format: 'binary',
        },
        documentTypeId: {
          type: 'integer',
          enum: [1, 2, 3],
        },
        isVisible: {
          type: 'boolean',
        },
      },
    },
  })
  async updateDocument(
    @Param('visitorId') visitorId: string,
    @Param('documentId') documentId: string,
    @UploadedFile() file: Express.Multer.File,
    @Body() update: Partial<DocumentFileDto>,
  ) {
    return this.documentsService.updateDocument(visitorId, documentId, update, file);
  }

  /**
   * Delete a document
   */
  @Delete('delete/:visitorId/:documentId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Delete document from a visitor' })
  @ApiResponse({
    status: HttpStatus.OK,
    description: 'Document deleted successfully.',
  })
  @ApiResponse({
    status: HttpStatus.NOT_FOUND,
    description: 'Visitor or document not found.',
  })
  async deleteDocument(
    @Param('visitorId') visitorId: string,
    @Param('documentId') documentId: string,
  ) {
    return this.documentsService.deleteDocument(visitorId, documentId);
  }
}
