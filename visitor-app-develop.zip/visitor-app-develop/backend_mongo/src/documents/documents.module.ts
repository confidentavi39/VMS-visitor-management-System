import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { DocumentsService } from './documents.service';
import { DocumentsController } from './documents.controller';
import { VisitorDocument, VisitorDocumentSchema } from '../schemas/visitor-document.schema';
import { StorageService } from '../utils/storage.service'; //

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: VisitorDocument.name, schema: VisitorDocumentSchema },
    ]),
  ],
  controllers: [DocumentsController],
  providers: [DocumentsService, StorageService], 
})
export class DocumentsModule {}
