import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { VisitorDocument } from '../schemas/visitor-document.schema';  // Ensure this is correct
import { DocumentFileDto } from './dto/document-file.dto';
import { Express } from 'express';
import { StorageService } from 'src/utils/storage.service';

@Injectable()
export class DocumentsService {
  constructor(
    @InjectModel(VisitorDocument.name) private readonly visitorModel: Model<VisitorDocument>,

    private readonly storageService: StorageService,  // Ensure the storage service is correctly injected
  ) { }

  // Method to upload new document
  async uploadNewDocument(
    visitorId: string,
    files: Express.Multer.File[],  // Expecting an array of files
    meta: DocumentFileDto[],  // Metadata for each file
  ) {
    const doc = await this.visitorModel.findOne({ visitorId });
    if (!doc) throw new NotFoundException('Visitor not found');

    // Define the correct type for uploadedDocuments
    const uploadedDocuments: { documentPath: string; documentTypeId: number; isVisible: boolean }[] = [];

    // Iterate over the files and metadata to process each file and its metadata
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const metadata = meta[i];

      // Generate a unique path for the file
      const path = `${visitorId}/${Date.now()}_${file.originalname}`;

      // Upload the file to the storage service
      const documentPath = await this.storageService.uploadFile(file, path);

      // Add document details to the visitor document
      doc.idProof.push({
        documentPath,
        documentTypeId: metadata.documentTypeId,
        isVisible: metadata.isVisible ?? true,
      });

      // Add the document to the uploadedDocuments array
      uploadedDocuments.push({
        documentPath,
        documentTypeId: metadata.documentTypeId,
        isVisible: metadata.isVisible ?? true,
      });
    }

    await doc.save();  // Save the updated visitor document
    return uploadedDocuments;
  }


  // Method to update document for a visitor
  async updateDocument(visitorId: string, documentId: string, update: Partial<DocumentFileDto>, file?: Express.Multer.File,) {
    const doc = await this.visitorModel.findOne({ visitorId });
    if (!doc) throw new NotFoundException('Visitor not found');

    const document = doc.idProof.find(doc => doc._id.toString() === documentId);
    if (!document) throw new NotFoundException('Document not found');

    // Update document fields based on the update DTO
    document.documentTypeId = update.documentTypeId || document.documentTypeId;
    document.isVisible = update.isVisible ?? document.isVisible;

    await doc.save();
    return document;
  }

  // Method to delete document for a visitor
  async deleteDocument(visitorId: string, documentId: string) {
    const doc = await this.visitorModel.findOne({ visitorId });
    if (!doc) throw new NotFoundException('Visitor not found');

    const documentIndex = doc.idProof.findIndex(doc => doc._id.toString() === documentId);
    if (documentIndex === -1) throw new NotFoundException('Document not found');

    // Remove the document from the idProof array
    doc.idProof.splice(documentIndex, 1);
    await doc.save();

    return { message: 'Document deleted successfully' };
  }
}
