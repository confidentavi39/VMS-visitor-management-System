import { Injectable } from '@nestjs/common';
import * as AWS from 'aws-sdk';
import { BlobServiceClient, StorageSharedKeyCredential } from '@azure/storage-blob';
import { ConfigService } from '@nestjs/config';
import * as fs from 'fs';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';
import * as moment from 'moment';
@Injectable()
export class StorageService {
    private storageType: string;
    private s3: AWS.S3;
    private azureBlobServiceClient: BlobServiceClient;
    private azureContainerClient;

    constructor(private configService: ConfigService) {
        this.storageType = this.configService.get<string>('STORAGE_SERVICE')!;

        if (this.storageType === 'aws') {
            AWS.config.update({
                accessKeyId: this.configService.get<string>('AWS_ACCESS_KEY_ID')!,
                secretAccessKey: this.configService.get<string>('AWS_SECRET_ACCESS_KEY')!,
                region: this.configService.get<string>('AWS_REGION')!,
            });
            this.s3 = new AWS.S3();
        } else if (this.storageType === 'azure') {
            const accountName = this.configService.get<string>('AZURE_STORAGE_ACCOUNT_NAME')!;
            const accountKey = this.configService.get<string>('AZURE_STORAGE_ACCOUNT_KEY')!;
            const credential = new StorageSharedKeyCredential(accountName, accountKey);
            this.azureBlobServiceClient = new BlobServiceClient(
                `https://${accountName}.blob.core.windows.net`,
                credential,
            );
            this.azureContainerClient = this.azureBlobServiceClient.getContainerClient(
                this.configService.get<string>('AZURE_CONTAINER_NAME')!,
            );
        }
    }

    /**
     * Upload file to the specified storage
     */
    async uploadFile(file: Express.Multer.File, filePath: string): Promise<string> {
        if (this.storageType === 'local') {
            const uploadDirectory = path.join(process.cwd(), 'uploads', 'documents');

            console.log('uploadDirectory:', uploadDirectory);

            if (!fs.existsSync(uploadDirectory)) {
                console.log('Creating upload/documents directory...');
                fs.mkdirSync(uploadDirectory, { recursive: true });
            }
            const uniqueId = uuidv4();

            const dateString = moment().format('YYYY-MM-DD_HH-mm-ss');

            const fileExtension = path.extname(file.originalname);

            const uniqueFileName = `${uniqueId}_${dateString}${fileExtension}`;

            const fullFilePath = path.join(uploadDirectory, uniqueFileName);

            console.log('Full File Path:', fullFilePath);

            fs.writeFileSync(fullFilePath, file.buffer);

            return `/uploads/documents/${uniqueFileName}`;
        } else if (this.storageType === 'aws') {
            const uploadParams = {
                Bucket: this.configService.get<string>('AWS_BUCKET_NAME')!,
                Key: filePath,
                Body: file.buffer,
            };
            await this.s3.upload(uploadParams).promise();
            return `https://${uploadParams.Bucket}.s3.amazonaws.com/${filePath}`;
        } else if (this.storageType === 'azure') {
            const blockBlobClient = this.azureContainerClient.getBlockBlobClient(filePath);
            await blockBlobClient.uploadData(file.buffer);
            const accountName = this.configService.get<string>('AZURE_STORAGE_ACCOUNT_NAME')!;
            return `https://${accountName}.blob.core.windows.net/${this.azureContainerClient.containerName}/${filePath}`;
        }

        throw new Error(`Unsupported storage type: ${this.storageType}`);
    }

    /**
     * Delete file from storage
     */
    async deleteFile(filePath: string): Promise<void> {
        if (this.storageType === 'local') {

            const fullFilePath = path.join(__dirname, '..', 'uploads', 'documents', filePath);
            if (fs.existsSync(fullFilePath)) {
                fs.unlinkSync(fullFilePath);
            }
        } else if (this.storageType === 'aws') {
            const deleteParams = {
                Bucket: this.configService.get<string>('AWS_BUCKET_NAME')!,
                Key: filePath,
            };
            await this.s3.deleteObject(deleteParams).promise();
        } else if (this.storageType === 'azure') {
            const blockBlobClient = this.azureContainerClient.getBlockBlobClient(filePath);
            await blockBlobClient.deleteIfExists();
        }
    }
}
