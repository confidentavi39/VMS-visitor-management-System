// sonar.ts
import scanner from 'sonarqube-scanner';
require('dotenv').config();

scanner(
  {
    serverUrl: 'http://localhost:9000',
    token: process.env.SONAR_TOKEN,
    options: {
      'sonar.projectKey': 'nestjs-backend-mongo',
      'sonar.sources': 'src',
      'sonar.exclusions': '**/*.spec.ts',
      'sonar.tests': '.',
      'sonar.test.inclusions': '**/*.spec.ts',
      'sonar.javascript.lcov.reportPaths': 'coverage/lcov.info',
    },
  },
  () => process.exit()
);
