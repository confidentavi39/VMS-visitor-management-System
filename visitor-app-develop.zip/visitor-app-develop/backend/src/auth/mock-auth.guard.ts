// src/auth/mock-auth.guard.ts
import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';

@Injectable()
export class MockAuthGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();

    // Simulate a logged-in user
    request.user = {
      id: 1,
      username: 'john',
      role: 'user', // Change to 'user' to simulate normal user
    };

    return true;
  }
}
