import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { JwtStrategy } from './jwt.strategy';
import { UsersModule } from 'src/users/users.module'; // ✅ Needed for UsersService

@Module({
  imports: [
    JwtModule.register({
      secret: 'my-secret', // Make sure this matches in JwtStrategy
      signOptions: { expiresIn: '1h' },
    }),
    UsersModule, // ✅ Required
  ],
  providers: [AuthService, JwtStrategy],
  controllers: [AuthController],
})
export class AuthModule {}
