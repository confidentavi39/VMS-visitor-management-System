import { Injectable, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { UsersService } from 'src/users/users.service';

@Injectable()
export class AuthService {
  constructor(
    private jwtService: JwtService,
    private usersService: UsersService,
  ) {}

  async login(user: { username: string; password: string }) {
    // Fetch user by username
    const dbUser = await this.usersService.findByUsername(user.username);

    if (!dbUser || !dbUser.password) {
      throw new UnauthorizedException('Invalid username or password');
    }

    // Compare provided password with stored hash
    const isPasswordValid = await bcrypt.compare(user.password, dbUser.password);
    if (!isPasswordValid) {
      throw new UnauthorizedException('Invalid username or password');
    }

    // Create JWT payload
    const payload = {
      username: dbUser.username,
      sub: dbUser.id,
      role: dbUser.role,
    };

    // Return signed JWT token
    return {
      access_token: this.jwtService.sign(payload),
    };
  }
}
