// src/auth/roles.enum.ts
export enum Role {
  User = 'user',
  Admin = 'admin',
}
