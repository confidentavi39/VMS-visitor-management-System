  import {
    Body,
    Controller,
    Delete,
    Get,
    HttpCode,
    HttpStatus,
    Param,
    Patch,
    Post,
    Request,
    UseGuards,
  } from '@nestjs/common';
  import { UsersService } from './users.service';
  import { CreateUsersDto } from 'src/dto/create-users.dto';
  import { MockAuthGuard } from 'src/auth/mock-auth.guard';
  import { RolesGuard } from 'src/auth/roles.guard';
  import { Role } from 'src/auth/roles.enum';
  import { Roles } from 'src/auth/roles.decorator';
  import { AuthGuard } from '@nestjs/passport';

  @Controller('users')
  export class UsersController {
    constructor(private userService: UsersService) {}
    
    
    @HttpCode(HttpStatus.CREATED)
    @Post('signup')
async signup(@Body() createUserDto: CreateUsersDto) {
  const user = await this.userService.create(createUserDto);
  return {
    message: 'User registered successfully',
    data: user,
  };
}

    @UseGuards(AuthGuard('jwt'), RolesGuard)
    @Get()
    @Roles(Role.Admin)
    async findAll() {
      return this.userService.findAll();
    }

    @UseGuards(AuthGuard('jwt'), RolesGuard)
    @Get('profile')
    @Roles(Role.User, Role.Admin)
    getProfile(@Request() req){
      return {
        message: "This is your profile",
        user: req.user
      }
    }

    // @UseGuards(AuthGuard('jwt'), RolesGuard)
    @Patch(':id')
    update(
      @Param('id') id: string,
      @Body() updatedData: Partial<CreateUsersDto>,
    ) {
      const updated = this.userService.update(+id, updatedData);
      if (!updated) return { message: 'User not found' };
      return updated;
    }

    @UseGuards(AuthGuard('jwt'), RolesGuard)
    @Roles(Role.Admin)
    @Delete(':id')
    remove(@Param('id') id: string) {
      return this.userService.remove(+id);
    }
    
  }
  
