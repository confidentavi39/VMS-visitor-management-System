// src/users/user.entity.ts
import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  username: string;

  @Column()
  age: number;

  @Column()
  address: string;

  @Column({ default: 'User' })
  role: string;

  @Column()
  password: string; // Needed for login
}
