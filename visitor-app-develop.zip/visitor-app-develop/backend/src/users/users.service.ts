import { Injectable, NotFoundException, Post } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { CreateUsersDto } from 'src/dto/create-users.dto';
import { User } from './user.entity';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
  ) {}

async create(data: CreateUsersDto) {
  const hashedPassword = await bcrypt.hash(data.password, 10);
  const user = this.userRepository.create({
    ...data,
    password: hashedPassword,
  });
  return this.userRepository.save(user);
}


// users.service.ts
async findByUsername(username: string) {
    const user =  this.userRepository.findOne({
    where: { username },
  });
  if(!user)
  {
    throw new NotFoundException("User not found")
  }

  return user;
}



  findAll() {
    return this.userRepository.find();
  }

  findOne(id: number) {
      const user = this.userRepository.findOneBy({ id });
      if(!user)
      {
        throw new NotFoundException("User not found")
      }
      return user;
  }

  async update(id: number, updatedUser: Partial<CreateUsersDto>) {
     await this.userRepository.update(id, updatedUser);
    return this.findOne(id);
  }

  async remove(id: number) {
    const result = await this.userRepository.delete(id);
    return (result.affected ?? 0) > 0;
  }
}
