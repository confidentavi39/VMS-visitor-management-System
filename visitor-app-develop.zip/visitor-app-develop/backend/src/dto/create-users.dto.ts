import { IsString, IsInt, Min } from 'class-validator';

export class CreateUsersDto {
  @IsString()
  username: string;

  @IsInt()
  @Min(0)
  age: number;

  @IsString()
  address: string;

  @IsString()
  role: string;

  @IsString()
  password: string;
}
