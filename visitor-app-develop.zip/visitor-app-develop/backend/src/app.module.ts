import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersModule } from './users/users.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './users/user.entity';
import { AuthModule } from './auth/auth.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
  type: 'postgres',       // Use PostgreSQL
  host: 'localhost',      // Your DB host
  port: 5432,             // Default PostgreSQL port
  username: 'postgres',   // Replace with your DB user
  password: 'Omkar@2002',   // Replace with your DB password
  database: 'nestdb',     // DB name to connect to
  entities: [User],       // Which models (entities) to use
  synchronize: true,      // Auto-create tables (dev only!)
}), AuthModule, UsersModule],
  controllers: [],
  providers: [],
})



export class AppModule {}
